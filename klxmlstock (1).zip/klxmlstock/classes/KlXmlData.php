<?php
/**
* @author    Antikov Evgeniy
* @copyright 2017-2020 kLooKva
* @license   http://opensource.org/licenses/afl-3.0.php  Academic Free License (AFL 3.0)
*/

class KlXmlData extends ObjectModel
{
    public $id_product;

    public $reference;

    public $data;

    /**
     * @see ObjectModel::$definition
     */
    public static $definition = array(
        'table' => 'kl_xmlstock',
        'primary' => 'id_product',
        'multilang' => false,
        'fields' => array(
            'reference' => array('type' => self::TYPE_STRING, 'lang' => false, 'validate' => 'isString'),
            'data' => array('type' => self::TYPE_STRING, 'lang' => false, 'validate' => 'isString'),
        )
    );

    public static function checkUniqueData($reference)
    {
        $sql = 'SELECT `reference` 
                FROM `'._DB_PREFIX_.'kl_xmlstock`
                WHERE `reference` = \''.$reference.'\'';

        return Db::getInstance()->getValue($sql);
    }

    public static function getReferenceDataExistsTable()
    {
        $res = false;
        $sql = 'SELECT `id_product` FROM `'._DB_PREFIX_.'product` WHERE 
                `reference` NOT IN (SELECT `reference` FROM `'._DB_PREFIX_.'kl_xmlstock`)
                ORDER By `'._DB_PREFIX_.'product`.`id_product` ASC';
        $sql = 'SELECT `id_product` FROM `'._DB_PREFIX_.'product` WHERE strlen(reference)>2 and 
                NOT exists (SELECT `reference` FROM `'._DB_PREFIX_.'kl_xmlstock` where reference = substring(`'._DB_PREFIX_.'product`.reference,0,16) )';

		$sql = 'SELECT '._DB_PREFIX_.'product.`id_product`
		FROM '._DB_PREFIX_.'product
		join '._DB_PREFIX_.'order_detail pod on pod.product_id = ps_product.id_product
		join '._DB_PREFIX_.'orders po on po.id_order = pod.id_order
		WHERE ps_product.`reference`<>"" and po.`date_add` > date_sub(curdate(), interval 45 day) and not EXISTS 
		(select `reference` FROM `'._DB_PREFIX_.'kl_xmlstock` where reference = substring('._DB_PREFIX_.'product.reference,1,16))
		UNION
		SELECT '._DB_PREFIX_.'product.`id_product`
		FROM '._DB_PREFIX_.'product
		join '._DB_PREFIX_.'supply_order_detail psod on psod.id_product = ps_product.id_product
		join '._DB_PREFIX_.'supply_order pso on pso.id_supply_order = psod.id_supply_order
		WHERE ps_product.`reference`<>"" and (pso.date_add > date_sub(curdate(), interval 45 day) or pso.id_supply_order = 525) and not EXISTS 
		(select `reference` FROM `'._DB_PREFIX_.'kl_xmlstock` where reference = substring('._DB_PREFIX_.'product.reference,1,16)) 
		UNION
		SELECT '._DB_PREFIX_.'product.`id_product`
		FROM '._DB_PREFIX_.'product
		join '._DB_PREFIX_.'pack p on p.`id_product_item`=ps_product.id_product
		join '._DB_PREFIX_.'order_detail pod on pod.product_id = p.`id_product_pack`
		join '._DB_PREFIX_.'orders po on po.id_order = pod.id_order
		WHERE ps_product.`reference`<>"" and po.`date_add` > date_sub(curdate(), interval 45 day) and not EXISTS 
		(select `reference` FROM `'._DB_PREFIX_.'kl_xmlstock` where reference = substring('._DB_PREFIX_.'product.reference,1,16));'; 


        $result = Db::getInstance()->executeS($sql);
        if (!empty($result)) {
            foreach ($result as $key) {
                $res[] = $key['id_product'];
            }
        }
        
        return $res;
    }
}
