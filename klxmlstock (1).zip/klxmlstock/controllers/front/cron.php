<?php
/**
* @author    Antikov Evgeniy
* @copyright 2017-2020 kLooKva
* @license   http://opensource.org/licenses/afl-3.0.php  Academic Free License (AFL 3.0)
*/

class KlXmlStockCronModuleFrontController extends ModuleFrontController
{
    public function initContent()
    {
        $encrypt_f = Tools::encrypt($this->module->name.'/index');
        if (Tools::getValue('token') != Tools::substr($encrypt_f, 0, 10)) {
            die($this->module->l('Invalid token'));
        }
        parent::initContent();
        if (Tools::getValue('action') == 'importStock') {
            $file = false;

            if (!empty($_FILES) &&
                array_key_exists('file', $_FILES) &&
                array_key_exists('tmp_name', $_FILES['file']) &&
                $_FILES['file']['size'] > 0
            ) {
                $file = $_FILES['file']['tmp_name'];
            }
            $this->module->importStock(Tools::getValue('login'), Tools::getValue('password'), $file);
            exit;
        } else {
            if (Tools::getValue('action') == 'insertXmlProduct') {
                $file = false;

                if (!empty($_FILES) &&
                    array_key_exists('file', $_FILES) &&
                    array_key_exists('tmp_name', $_FILES['file']) &&
                    $_FILES['file']['size'] > 0
                ) {
                    $file = $_FILES['file']['tmp_name'];
                }
                $this->module->insertXmlProduct(Tools::getValue('login'), Tools::getValue('password'), $file);
                exit;
            } else {
                if (Tools::getValue('action') == 'uploadFile') {
                    $this->module->newXmlProductList();
                    exit;
                }
            }
        }
        $this->module->addToLog($this->module->l('There is no such action'), 'error');
        exit;
    }
}
