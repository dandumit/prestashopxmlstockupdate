<?php
/**
* @author    Antikov Evgeniy
* @copyright 2017-2018 kLooKva
* @license   http://opensource.org/licenses/afl-3.0.php  Academic Free License (AFL 3.0)
*/

if (!defined('_PS_VERSION_')) {
    exit;
}

function upgrade_module_1_0_1()
{
    $sql = 'CREATE TABLE IF NOT EXISTS`'. _DB_PREFIX_.'kl_xmlstock` (
            `id_product` INT AUTO_INCREMENT,
            `reference` VARCHAR(64) NOT NULL,
            `data` VARCHAR(1000),
            PRIMARY KEY (id_product)
        ) ENGINE='._MYSQL_ENGINE_.' DEFAULT CHARSET=utf8; ';
	
	$sql .= ' ALTER TABLE `'. _DB_PREFIX_.'kl_xmlstock` ADD UNIQUE KEY `reference` (`reference`);';
    
	return Db::getInstance()->execute($sql);
	
	
}
