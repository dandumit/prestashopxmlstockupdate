<?php
/**
* @author    Antikov Evgeniy
* @copyright 2017-2018 kLooKva
* @license   http://opensource.org/licenses/afl-3.0.php  Academic Free License (AFL 3.0)
*/

if (!defined('_PS_VERSION_')) {
    exit;
}

include_once _PS_MODULE_DIR_ . 'klxmlstock/classes/KlXmlData.php';

class KlXmlStock extends Module
{
    protected $html = '';
    protected $cron_url;
    protected $logger;
    protected $params;
    protected $task_name = 'default';
    protected $main_cod = 'linie';
    protected $cod = array(
        'reference' => 'cod',
        'quantity' => 'stoc'
    );
    
    public function __construct()
    {
        $this->name = 'klxmlstock';
        $this->tab = 'administration';
        $this->version = '1.0.1';
        $this->author = 'kLooKva Antikov';
        $this->need_instance = 0;

        $this->bootstrap = true;
        parent::__construct();

        $this->initializeLogger();
        $this->cron_url = $this->context->link->getModuleLink($this->name, 'cron', array(
            'token' => Tools::substr(Tools::encrypt($this->name.'/index'), 0, 10)
        ));

        $this->params = Tools::jsonDecode(Configuration::get($this->name), true);

        $this->displayName = $this->l('Klookva xml product stock import');
        $this->description = $this->l('Import by xml link products stock');
        $this->ps_versions_compliancy = array('min' => '1.5', 'max' => _PS_VERSION_);
    }

    public function install()
    {
        $params = array(
            'login' => '',
            'password' => ''
        );
        return parent::install() &&
            Configuration::updateValue($this->name, Tools::jsonEncode($params)) && $this->installDB();
    }

    public function uninstall()
    {
        return Configuration::deleteByName($this->name)
            && parent::uninstall() && $this->uninstallDB();
    }

    protected function initializeLogger()
    {
        if (!class_exists('Monolog\Logger')) {
            include_once _PS_MODULE_DIR_.$this->name.'/lib/vendor/autoload.php';
        }
        
        $this->logger = new Monolog\Logger($this->name.'_logger');

        $this->logger->pushHandler(
            new Monolog\Handler\StreamHandler(
                _PS_MODULE_DIR_.$this->name.'/log/default.log',
                Monolog\Logger::DEBUG
            )
        );
        $this->logger->pushHandler(new Monolog\Handler\FirePHPHandler());
    }

    protected function listDirByDate($pathtosearch)
    {
        $file_array = array();
        foreach (glob($pathtosearch) as $filename) {
            if (Tools::substr(basename($filename), -4) == '.php') {
                continue;
            }
            $file_array[filectime($filename)] = basename($filename);
        }
        krsort($file_array);
        return $file_array;
    }

    public function getContent()
    {
        $this->html .= $this->adminDisplayInformation($this->l('[URL] Import files:').' '.
            $this->cron_url.'&action=<b>importStock</b>');
        
        $this->html .= $this->adminDisplayInformation("<br>");
        
        $dir = _PS_ROOT_DIR_.'/modules/'.$this->name.'/log/*';
        $sorted_array = $this->listDirByDate($dir);
        $this->html .= $this->adminDisplayInformation($this->l('List of log files:'));
        foreach ($sorted_array as $log) {
            $this->html .= $this->adminDisplayInformation('<a href="/modules/'.
                $this->name.'/log/'.$log.'">'.$log.'</a>');
        }

        $this->html .= $this->adminDisplayInformation('<hr>');
        $this->html .= $this->adminDisplayInformation($this->l('[URL] Import files:').' '.
            $this->cron_url.'&action=<b>insertXmlProduct</b>');
        
        $this->html .= $this->adminDisplayInformation("<br>");
        $this->html .= $this->adminDisplayInformation('<a href="'.$this->cron_url.'&action=uploadFile">'.
            $this->l('Download Xml File').'</a>');

        if (Tools::isSubmit('save'.$this->name.'_settings')) {
            $this->html .= $this->saveSettings();
        }

        return $this->html.$this->renderForm();
    }

    protected function saveSettings()
    {
        $results = array(
            'login' => Tools::getValue('login'),
            'password' => Tools::getValue('password')

        );
        if (Configuration::updateValue($this->name, Tools::jsonEncode($results))) {
            $this->params = Tools::jsonDecode(Configuration::get($this->name), true);
            return $this->displayConfirmation($this->l('Settings updated'));
        }
        return $this->displayError($this->l('Error occured during data saving'));
    }

    public function renderForm()
    {
        $fields_form = array(
            'form' => array(
                'legend' => array(
                    'title' => $this->l('Settings'),
                    'icon' => 'icon-setting'
                ),
                'input' => array(
                    array(
                        'type' => 'text',
                        'label' => $this->l('Login'),
                        'required' => true,
                        'name' => 'login',
                    ),
                    array(
                        'type' => 'text',
                        'label' => $this->l('Password'),
                        'required' => true,
                        'name' => 'password',
                    ),
                ),
                'submit' => array(
                    'title' => $this->l('Save'),
                )
            ),
        );

        $helper = new HelperForm();
        $helper->show_toolbar = false;
        $helper->table = $this->table;
        $lang = new Language((int)Configuration::get('PS_LANG_DEFAULT'));
        $helper->default_form_language = $lang->id;
        $helper->allow_employee_form_lang = Configuration::get('PS_BO_ALLOW_EMPLOYEE_FORM_LANG') ?
        Configuration::get('PS_BO_ALLOW_EMPLOYEE_FORM_LANG') : 0;
        $helper->identifier = $this->identifier;
        $helper->submit_action = 'save'.$this->name.'_settings';
        $helper->currentIndex = $this->context->link->getAdminLink('AdminModules', false).'&configure='.
        $this->name.'&tab_module='.$this->tab.'&module_name='.$this->name;
        $helper->token = Tools::getAdminTokenLite('AdminModules');
        $helper->tpl_vars = array(
            'fields_value' => $this->params,
            'languages' => $this->context->controller->getLanguages(),
            'id_language' => $this->context->language->id
        );

        return $helper->generateForm(array($fields_form));
    }


    public function getParseProducts($file, $path)
    {
        $products = array();
        try {
            $xml = new XMLReader();
            $xml->open($file);
            if ($xml === false) {
                return array();
            }

            while ($xml->read()) {
                if ($xml->name != $path) {
                    continue;
                }
                $products[] = $this->parsePartOfItem($xml->readOuterXML());
            }
        } catch (\Exception $e) {
            echo "<p> exception  ! " . $e;
            return $products;
        }

        return $products;
    }

    protected function parsePartOfItem($part)
    {
        $line = str_replace('<g:', '<', $part);
        $line = str_replace('</g:', '</', $line);
        $element = new SimpleXMLElement($line, LIBXML_NOCDATA);
        return (array)$element;
    }

    protected function getColoredString($string, $front = null, $back = null)
    {
        $foreground_colors = array(
            'black' => '0;30',
            'dark_gray' => '1;30',
            'blue' => '0;34',
            'light_blue' => '1;34',
            'green' => '0;32',
            'light_green' => '1;32',
            'cyan' => '0;36',
            'light_cyan' => '1;36',
            'red' => '0;31',
            'light_red' => '1;31',
            'purple' => '0;35',
            'light_purple' => '1;35',
            'brown' => '0;33',
            'yellow' => '1;33',
            'light_gray' => '0;37',
            'white' => '1;37'
        );

        $background_colors = array(
            'black' => '40',
            'red' => '41',
            'green' => '42',
            'yellow' => '43',
            'blue' => '44',
            'magenta' => '45',
            'cyan' => '46',
            'light_gray' => '47'
        );
        $colored_string = "";

        if (isset($foreground_colors[$front])) {
            $colored_string .= "\033[" . $foreground_colors[$front] . "m";
        }

        if (isset($background_colors[$back])) {
            $colored_string .= "\033[" . $background_colors[$back] . "m";
        }

        $colored_string .=  $string . "\033[0m";

        return $colored_string;
    }

    public function addToLog($message, $type = 'info')
    {
        if (!is_string($message)) {
            return false;
        }

        $echo = '['.date('Y-m-d H:i:s').']['.$this->task_name.'] '.$message;
        $front = 'white';
        switch ($type) {
            case 'error':
                $back = 'red';
                break;
            case 'warning':
                $front = 'black';
                $back = 'yellow';
                break;
            case 'notice':
                $back = 'blue';
                break;
            case 'correct':
                $front = 'brown';
                $back = 'cyan';
                break;
            default:
                $front = 'black';
                $back = 'green';
                break;
        }
        if (php_sapi_name() == 'cli') {
            echo $this->getColoredString($echo, $front, $back).PHP_EOL;
        } else {
            echo '<span style="background-color: '.$back.';color: '.$front.';">'.$echo.'</span><br>';
        }

        if (!method_exists($this->logger, $type)) {
            $type = 'info';
        }

        $this->logger->{$type}($message, array($this->task_name));
    }

    public function importStock($login, $password, $file)
    {
        if ($login != $this->params['login'] ||
            $password != $this->params['password']
        ) {
            $this->addToLog($this->l('Bad login or password'), 'error');
            return false;
        }
        if (!$file || !Tools::file_get_contents($file)) {
            $this->addToLog($this->l('Bad file'), 'error');
            return false;
        }
        $xmls = $this->getParseProducts($file, $this->main_cod);
		$sql= 'Truncate TABLE `'._DB_PREFIX_.'kl_xmlstock`;';
		Db::getInstance()->execute($sql);
		//$this->addToLog($this->l('Execut >')." ". $sql, 'error');
        foreach ($xmls as $key) {
            if (empty($key)) {
                continue;
            }
			$sql= 'insert into `'._DB_PREFIX_.'kl_xmlstock` (reference,data) values ("'.$key[$this->cod['reference']].'","'.$key[$this->cod['quantity']].'");';
			Db::getInstance()->execute($sql);
			//$this->addToLog($this->l('Execut >')." ". $sql, 'error');
            $id_product = $this->getIdproductByReference($key[$this->cod['reference']]);
            if (!$id_product) {
                $this->addToLog($this->l('No product reference in DB:').' '.$key[$this->cod['reference']], 'error');
                continue;
            }
            if ($this->updateQuantityByIdProduct($id_product, (int)$this->getQuantity($key[$this->cod['quantity']]))) {
                $this->addToLog($this->l('\n Success update quantity in product:').' '.$id_product);
            } else {
                $this->addToLog($this->l('\n Error update quantity in product:').' '.$id_product, 'error');
            }
        }

        $this->addToLog($this->l('\n All products are update'), 'notice');
    }

    protected function getQuantity($name)
    {
        if (is_numeric($name)) {
            return $name;
        }
        switch ($name) {
            case $name == 'available':
            case $name == 'in stock':
                return 999;
            case $name == 'low stock':
                return 3;
            case $name == 'out of stock':
                return 0;
            default:
                return 0;
        }
    }

    public function getIdproductByReference($reference)
    {
        $sql = 'SELECT `id_product`
                FROM `'._DB_PREFIX_.'product`
                WHERE TRIM(`reference`) = "'.pSQL(trim($reference)).'"';
        $res = Db::getInstance()->getValue($sql);

        if (!$res) {
            $sql = 'SELECT `id_product`
                FROM `'._DB_PREFIX_.'product_attribute`
                WHERE TRIM(`reference`) = "'.pSQL(trim($reference)).'"';
            $res = Db::getInstance()->getValue($sql);
        }

        return $res;
    }

    public function updateQuantityByIdProduct($id_product, $quantity)
    {
        $sql = 'UPDATE `'._DB_PREFIX_.'product`
                SET quantity = '.(int)$quantity.'
                WHERE id_product = '.(int)$id_product.';
                UPDATE `'._DB_PREFIX_.'product_attribute`
                SET quantity = '.(int)$quantity.'
                WHERE id_product = '.(int)$id_product.';
                UPDATE `'._DB_PREFIX_.'stock_available`
                SET quantity = '.(int)$quantity.'
                WHERE id_product = '.(int)$id_product.';';

        return Db::getInstance()->execute($sql);
    }

    public function newXmlProductList()
    {
        $xmlname = 'ART_'. date('d', time()) . date('G', time()). '.xml';
        $product_list = KlXmlData::getReferenceDataExistsTable();
        if ($product_list == false) {
            return $this->addToLog($this->l('\n No products found'), 'notice');
        }

        $xw = xmlwriter_open_memory();
        xmlwriter_set_indent($xw, 1);

        xmlwriter_start_document($xw, '1.0', 'UTF-8');

        xmlwriter_start_element($xw, 'articole');
        foreach ($product_list as $product) {
            $xmlprod = new Product($product);
            xmlwriter_start_element($xw, 'linie');

            xmlwriter_start_element($xw, 'cod');
                xmlwriter_text($xw, $xmlprod->reference);
            xmlwriter_end_element($xw);

            xmlwriter_start_element($xw, 'denumire');
                xmlwriter_text($xw, (string)$xmlprod->name[1]);
            xmlwriter_end_element($xw);

            xmlwriter_start_element($xw, 'tip');
                xmlwriter_text($xw, '01');
            xmlwriter_end_element($xw);
            xmlwriter_start_element($xw, 'den_tip');
                xmlwriter_text($xw, 'Marfuri');
            xmlwriter_end_element($xw);
            xmlwriter_start_element($xw, 'um');
                xmlwriter_text($xw, 'BUC');
            xmlwriter_end_element($xw);

            xmlwriter_start_element($xw, 'cod_bare');
                xmlwriter_text($xw, $xmlprod->ean13);
            xmlwriter_end_element($xw);

//		<p_tva>20</p_tva>
//		<pret>0.0000</pret>
//		<pret_tva>0.0000</pret_tva>
//		<informatii/>
//		<stoc>27.0000</stoc>
//		<aprovizionabil>1</aprovizionabil>
//		<vandabil>1</vandabil>
            xmlwriter_end_element($xw);
        }
        xmlwriter_end_element($xw);
        xmlwriter_end_document($xw);
        header('Content-type: "text/xml"; charset="utf8"');
        header('Content-disposition: attachment; filename=' . $xmlname);


        echo xmlwriter_output_memory($xw);
    }

    public function insertXmlProduct($login, $password, $file)
    {
        if ($login != $this->params['login'] ||
            $password != $this->params['password']
        ) {
            $this->addToLog($this->l('Bad login or password'), 'error');
            return false;
        }
        if (!$file || !Tools::file_get_contents($file)) {
            $this->addToLog($this->l('Bad file'), 'error');
            return false;
        }
        $xmls = $this->getParseProducts($file, $this->main_cod);
        foreach ($xmls as $key) {
            if (empty($key)) {
                continue;
            }
            $reference = $key[$this->cod['reference']];
            $data = json_encode($key);

            if ($reference != KlXmlData::checkUniqueData($reference)) {
                $kl_xml_stoc = new KlXmlData();
                $kl_xml_stoc->force_id = true;
                $kl_xml_stoc->reference = $reference;
                $kl_xml_stoc->data = $data;
                $kl_xml_stoc->add();
            }
        }

        $this->addToLog($this->l('\n Data recorded'), 'notice');
    }

    public function installDB()
    {
        return Db::getInstance()->execute('CREATE TABLE IF NOT EXISTS`'. _DB_PREFIX_.'kl_xmlstock` (
            `id_product` INT AUTO_INCREMENT,
            `reference` VARCHAR(64) NOT NULL,
            `data` VARCHAR(1000),
            PRIMARY KEY (id_product)
        ) ENGINE='._MYSQL_ENGINE_.' DEFAULT CHARSET=utf8 ; ALTER TABLE `'. _DB_PREFIX_.'kl_xmlstock` ADD UNIQUE KEY `reference` (`reference`); ');
    }

    public function uninstallDB()
    {
        return Db::getInstance()->execute('DROP TABLE `'._DB_PREFIX_.'kl_xmlstock`');
    }
}
